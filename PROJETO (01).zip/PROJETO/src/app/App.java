package app;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import mvc.controller.AlunoController;
import mvc.controller.DisciplinaController;
import mvc.controller.NotaController;
import mvc.controller.TipoProvaController;
import mvc.view.PrincipalView;

public class App {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                PrincipalView view = new PrincipalView();

                // Liga cada tela ao seu Controller
                new AlunoController(view.getAlunoView());
                new DisciplinaController(view.getDisciplinaView());
                new TipoProvaController(view.getTipoProvaView());
                new NotaController(view);

                view.setVisible(true);
            }
        });
    }
}