package mvc.controller;

import java.util.ArrayList;
import java.util.List;
import mvc.model.Aluno;
import mvc.model.Disciplina;
import mvc.model.Nota;
import mvc.model.TipoProva;
import mvc.view.NotaView;
import mvc.view.PrincipalView;

public class NotaController {

    private static final int ABA_NOTAS = 3;

    private final PrincipalView principal;
    private final NotaView view;
    private final NotaDAO dao = new NotaDAO();
    private final AlunoDAO alunoDAO = new AlunoDAO();
    private final DisciplinaDAO disciplinaDAO = new DisciplinaDAO();
    private final TipoProvaDAO tipoProvaDAO = new TipoProvaDAO();

    public NotaController(PrincipalView principal) {
        this.principal = principal;
        this.view = principal.getNotaView();

        view.addCadastrarListener(e -> cadastrar());
        view.addAtualizarListener(e -> atualizar());
        view.addExcluirListener(e -> excluir());

        // Sempre que o usuario abrir a aba Notas, recarrega combos e tabela
        principal.addTrocaAbaListener(e -> {
            if (principal.getAbaSelecionada() == ABA_NOTAS) {
                carregarCombos();
                listar();
            }
        });

        carregarCombos();
        listar();
    }

    private void carregarCombos() {
        try {
            view.setAlunos(alunoDAO.listar());
            view.setDisciplinas(disciplinaDAO.listar());
            view.setTiposProva(tipoProvaDAO.listar());
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao carregar alunos/disciplinas/tipos: " + ex.getMessage());
        }
    }

    /** Monta a Nota a partir dos campos; retorna null (e avisa) se algo estiver invalido. */
    private Nota lerFormulario() {
        Object a = view.getAlunoSelecionado();
        Object d = view.getDisciplinaSelecionada();
        Object t = view.getTipoProvaSelecionado();
        if (a == null || d == null || t == null) {
            view.mostrarErro("Cadastre e selecione aluno, disciplina e tipo de prova.");
            return null;
        }
        double valor;
        try {
            valor = Double.parseDouble(view.getValor());
        } catch (NumberFormatException ex) {
            view.mostrarErro("Digite uma nota valida (ex.: 7.5).");
            return null;
        }
        if (valor < 0 || valor > 10) {
            view.mostrarErro("A nota deve estar entre 0 e 10.");
            return null;
        }
        Nota n = new Nota();
        n.setAluno((Aluno) a);
        n.setDisciplina((Disciplina) d);
        n.setTipoProva((TipoProva) t);
        n.setValor(valor);
        return n;
    }

    private void cadastrar() {
        try {
            Nota n = lerFormulario();
            if (n == null) return;
            dao.inserir(n);
            listar();
            view.limpar();
            view.mostrarMensagem("Nota cadastrada com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao cadastrar: " + ex.getMessage());
        }
    }

    private void atualizar() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione uma nota na tabela.");
                return;
            }
            Nota n = lerFormulario();
            if (n == null) return;
            n.setId(Integer.parseInt(view.getId()));
            dao.atualizar(n);
            listar();
            view.limpar();
            view.mostrarMensagem("Nota atualizada com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao atualizar: " + ex.getMessage());
        }
    }

    private void excluir() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione uma nota na tabela.");
                return;
            }
            if (!view.confirmarExclusao()) return;
            dao.excluir(Integer.parseInt(view.getId()));
            listar();
            view.limpar();
            view.mostrarMensagem("Nota excluida com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao excluir: " + ex.getMessage());
        }
    }

    private void listar() {
        try {
            List<Object[]> linhas = new ArrayList<>();
            for (Nota n : dao.listar()) {
                linhas.add(new Object[]{
                    n.getId(),
                    n.getAluno().toString(),
                    n.getDisciplina().toString(),
                    n.getTipoProva().toString(),
                    n.getValor()
                });
            }
            view.setLinhas(linhas);
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao listar notas: " + ex.getMessage());
        }
    }
}