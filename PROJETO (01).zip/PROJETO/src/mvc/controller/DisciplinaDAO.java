package mvc.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mvc.model.Disciplina;

public class DisciplinaDAO {

    public void inserir(Disciplina d) throws SQLException {
        String sql = "INSERT INTO disciplinas (disciplina) VALUES (?)";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, d.getNome());
            ps.executeUpdate();
        }
    }

    public void atualizar(Disciplina d) throws SQLException {
        String sql = "UPDATE disciplinas SET disciplina = ? WHERE id_disciplina = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, d.getNome());
            ps.setInt(2, d.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM disciplinas WHERE id_disciplina = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Disciplina> listar() throws SQLException {
        List<Disciplina> lista = new ArrayList<>();
        String sql = "SELECT id_disciplina, disciplina FROM disciplinas ORDER BY id_disciplina";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Disciplina(rs.getInt("id_disciplina"), rs.getString("disciplina")));
            }
        }
        return lista;
    }
}