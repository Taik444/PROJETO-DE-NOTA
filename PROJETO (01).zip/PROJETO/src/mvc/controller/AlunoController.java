package mvc.controller;

import java.util.ArrayList;
import java.util.List;
import mvc.model.Aluno;
import mvc.view.AlunoView;

public class AlunoController {

    private final AlunoView view;
    private final AlunoDAO dao = new AlunoDAO();

    public AlunoController(AlunoView view) {
        this.view = view;
        view.addCadastrarListener(e -> cadastrar());
        view.addAtualizarListener(e -> atualizar());
        view.addExcluirListener(e -> excluir());
        listar();
    }

    private void cadastrar() {
        try {
            if (view.getNome().isEmpty()) {
                view.mostrarErro("Preencha o nome do aluno.");
                return;
            }
            int id = 0; // 0 = o banco gera o ID sozinho
            if (!view.getIdDigitado().isEmpty()) {
                try {
                    id = Integer.parseInt(view.getIdDigitado());
                } catch (NumberFormatException ex) {
                    view.mostrarErro("O ID deve ser um numero inteiro.");
                    return;
                }
                if (id <= 0) {
                    view.mostrarErro("O ID deve ser maior que zero.");
                    return;
                }
            }
            dao.inserir(new Aluno(id, view.getNome()));
            listar();
            view.limpar();
            view.mostrarMensagem("Aluno cadastrado com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao cadastrar (o ID pode ja existir): " + ex.getMessage());
        }
    }

    private void atualizar() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione um aluno na tabela.");
                return;
            }
            if (view.getNome().isEmpty()) {
                view.mostrarErro("Preencha o nome do aluno.");
                return;
            }
            dao.atualizar(new Aluno(Integer.parseInt(view.getId()), view.getNome()));
            listar();
            view.limpar();
            view.mostrarMensagem("Aluno atualizado com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao atualizar: " + ex.getMessage());
        }
    }

    private void excluir() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione um aluno na tabela.");
                return;
            }
            if (!view.confirmarExclusao()) return;
            dao.excluir(Integer.parseInt(view.getId()));
            listar();
            view.limpar();
            view.mostrarMensagem("Aluno excluido com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao excluir (o aluno pode ter notas cadastradas): " + ex.getMessage());
        }
    }

    private void listar() {
        try {
            List<Object[]> linhas = new ArrayList<>();
            for (Aluno a : dao.listar()) {
                linhas.add(new Object[]{a.getId(), a.getNome()});
            }
            view.setLinhas(linhas);
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao listar alunos: " + ex.getMessage());
        }
    }
}