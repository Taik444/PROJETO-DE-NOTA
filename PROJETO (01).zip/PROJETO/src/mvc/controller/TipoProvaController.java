package mvc.controller;

import java.util.ArrayList;
import java.util.List;
import mvc.model.TipoProva;
import mvc.view.TipoProvaView;

public class TipoProvaController {

    private final TipoProvaView view;
    private final TipoProvaDAO dao = new TipoProvaDAO();

    public TipoProvaController(TipoProvaView view) {
        this.view = view;
        view.addCadastrarListener(e -> cadastrar());
        view.addAtualizarListener(e -> atualizar());
        view.addExcluirListener(e -> excluir());
        listar();
    }

    private void cadastrar() {
        try {
            if (view.getDescricao().isEmpty()) {
                view.mostrarErro("Preencha a descricao do tipo de prova.");
                return;
            }
            dao.inserir(new TipoProva(0, view.getDescricao()));
            listar();
            view.limpar();
            view.mostrarMensagem("Tipo de prova cadastrado com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao cadastrar: " + ex.getMessage());
        }
    }

    private void atualizar() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione um tipo de prova na tabela.");
                return;
            }
            if (view.getDescricao().isEmpty()) {
                view.mostrarErro("Preencha a descricao do tipo de prova.");
                return;
            }
            dao.atualizar(new TipoProva(Integer.parseInt(view.getId()), view.getDescricao()));
            listar();
            view.limpar();
            view.mostrarMensagem("Tipo de prova atualizado com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao atualizar: " + ex.getMessage());
        }
    }

    private void excluir() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione um tipo de prova na tabela.");
                return;
            }
            if (!view.confirmarExclusao()) return;
            dao.excluir(Integer.parseInt(view.getId()));
            listar();
            view.limpar();
            view.mostrarMensagem("Tipo de prova excluido com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao excluir (o tipo pode ter notas cadastradas): " + ex.getMessage());
        }
    }

    private void listar() {
        try {
            List<Object[]> linhas = new ArrayList<>();
            for (TipoProva t : dao.listar()) {
                linhas.add(new Object[]{t.getId(), t.getDescricao()});
            }
            view.setLinhas(linhas);
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao listar tipos de prova: " + ex.getMessage());
        }
    }
}