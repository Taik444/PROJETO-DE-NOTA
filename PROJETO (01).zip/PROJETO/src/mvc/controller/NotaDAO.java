package mvc.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mvc.model.Aluno;
import mvc.model.Disciplina;
import mvc.model.Nota;
import mvc.model.TipoProva;

public class NotaDAO {

    public void inserir(Nota n) throws SQLException {
        String sql = "INSERT INTO notas (id_disciplina, id_tipo_de_prova, id_aluno, nota) VALUES (?, ?, ?, ?)";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, n.getDisciplina().getId());
            ps.setInt(2, n.getTipoProva().getId());
            ps.setInt(3, n.getAluno().getId());
            ps.setDouble(4, n.getValor());
            ps.executeUpdate();
        }
    }

    public void atualizar(Nota n) throws SQLException {
        String sql = "UPDATE notas SET id_disciplina = ?, id_tipo_de_prova = ?, id_aluno = ?, nota = ? WHERE id_nota = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, n.getDisciplina().getId());
            ps.setInt(2, n.getTipoProva().getId());
            ps.setInt(3, n.getAluno().getId());
            ps.setDouble(4, n.getValor());
            ps.setInt(5, n.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM notas WHERE id_nota = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Nota> listar() throws SQLException {
        List<Nota> lista = new ArrayList<>();
        String sql = "SELECT n.id_nota, n.nota, "
                + "a.id_aluno, a.nome_do_aluno, "
                + "d.id_disciplina, d.disciplina, "
                + "t.id_tipo_de_prova, t.tipo_de_prova "
                + "FROM notas n "
                + "JOIN alunos a ON a.id_aluno = n.id_aluno "
                + "JOIN disciplinas d ON d.id_disciplina = n.id_disciplina "
                + "JOIN tipos_de_prova t ON t.id_tipo_de_prova = n.id_tipo_de_prova "
                + "ORDER BY n.id_nota";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Nota n = new Nota();
                n.setId(rs.getInt("id_nota"));
                n.setValor(rs.getDouble("nota"));
                n.setAluno(new Aluno(rs.getInt("id_aluno"), rs.getString("nome_do_aluno")));
                n.setDisciplina(new Disciplina(rs.getInt("id_disciplina"), rs.getString("disciplina")));
                n.setTipoProva(new TipoProva(rs.getInt("id_tipo_de_prova"), rs.getString("tipo_de_prova")));
                lista.add(n);
            }
        }
        return lista;
    }
}