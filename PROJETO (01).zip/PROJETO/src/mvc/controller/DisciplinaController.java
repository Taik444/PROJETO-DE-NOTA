package mvc.controller;

import java.util.ArrayList;
import java.util.List;
import mvc.model.Disciplina;
import mvc.view.DisciplinaView;

public class DisciplinaController {

    private final DisciplinaView view;
    private final DisciplinaDAO dao = new DisciplinaDAO();

    public DisciplinaController(DisciplinaView view) {
        this.view = view;
        view.addCadastrarListener(e -> cadastrar());
        view.addAtualizarListener(e -> atualizar());
        view.addExcluirListener(e -> excluir());
        listar();
    }

    private void cadastrar() {
        try {
            if (view.getNome().isEmpty()) {
                view.mostrarErro("Preencha o nome da disciplina.");
                return;
            }
            dao.inserir(new Disciplina(0, view.getNome()));
            listar();
            view.limpar();
            view.mostrarMensagem("Disciplina cadastrada com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao cadastrar: " + ex.getMessage());
        }
    }

    private void atualizar() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione uma disciplina na tabela.");
                return;
            }
            if (view.getNome().isEmpty()) {
                view.mostrarErro("Preencha o nome da disciplina.");
                return;
            }
            dao.atualizar(new Disciplina(Integer.parseInt(view.getId()), view.getNome()));
            listar();
            view.limpar();
            view.mostrarMensagem("Disciplina atualizada com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao atualizar: " + ex.getMessage());
        }
    }

    private void excluir() {
        try {
            if (!view.temLinhaSelecionada()) {
                view.mostrarErro("Selecione uma disciplina na tabela.");
                return;
            }
            if (!view.confirmarExclusao()) return;
            dao.excluir(Integer.parseInt(view.getId()));
            listar();
            view.limpar();
            view.mostrarMensagem("Disciplina excluida com sucesso!");
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao excluir (a disciplina pode ter notas cadastradas): " + ex.getMessage());
        }
    }

    private void listar() {
        try {
            List<Object[]> linhas = new ArrayList<>();
            for (Disciplina d : dao.listar()) {
                linhas.add(new Object[]{d.getId(), d.getNome()});
            }
            view.setLinhas(linhas);
        } catch (Exception ex) {
            ex.printStackTrace();
            view.mostrarErro("Erro ao listar disciplinas: " + ex.getMessage());
        }
    }
}