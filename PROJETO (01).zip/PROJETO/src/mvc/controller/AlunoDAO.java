package mvc.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import mvc.model.Aluno;

public class AlunoDAO {

    /** Se o id for maior que 0, usa o id informado; senao o banco gera (AUTO_INCREMENT). */
    public void inserir(Aluno a) throws SQLException {
        boolean comId = a.getId() > 0;
        String sql = comId
                ? "INSERT INTO alunos (id_aluno, nome_do_aluno) VALUES (?, ?)"
                : "INSERT INTO alunos (nome_do_aluno) VALUES (?)";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            if (comId) {
                ps.setInt(1, a.getId());
                ps.setString(2, a.getNome());
            } else {
                ps.setString(1, a.getNome());
            }
            ps.executeUpdate();
        }
    }

    public void atualizar(Aluno a) throws SQLException {
        String sql = "UPDATE alunos SET nome_do_aluno = ? WHERE id_aluno = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, a.getNome());
            ps.setInt(2, a.getId());
            ps.executeUpdate();
        }
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM alunos WHERE id_aluno = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Aluno> listar() throws SQLException {
        List<Aluno> lista = new ArrayList<>();
        String sql = "SELECT id_aluno, nome_do_aluno FROM alunos ORDER BY id_aluno";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Aluno(rs.getInt("id_aluno"), rs.getString("nome_do_aluno")));
            }
        }
        return lista;
    }
}