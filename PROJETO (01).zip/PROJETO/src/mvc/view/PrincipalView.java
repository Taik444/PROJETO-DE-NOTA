package mvc.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;

public class PrincipalView extends JFrame {

    private final NotaView notaView = new NotaView();
    private final AlunoView alunoView = new AlunoView();
    private final DisciplinaView disciplinaView = new DisciplinaView();
    private final TipoProvaView tipoProvaView = new TipoProvaView();
    private final JTabbedPane abas = new JTabbedPane();

    public PrincipalView() {
        super("Controle de Notas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Faixa azul no topo
        JLabel titulo = new JLabel("Controle de Notas");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 22f));
        JLabel subtitulo = new JLabel("Cadastro de alunos, disciplinas, tipos de prova e notas");
        subtitulo.setForeground(new Color(0xCFE3F8));

        JPanel textos = new JPanel(new GridLayout(2, 1));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(subtitulo);

        JPanel topo = new JPanel(new BorderLayout());
        topo.setBackground(CadastroBaseView.AZUL_ESCURO);
        topo.setBorder(new EmptyBorder(14, 18, 14, 18));
        topo.add(textos, BorderLayout.WEST);

        // Ordem das abas: Alunos (abre primeiro), Disciplinas, Tipos de Prova e Notas
        abas.setFont(abas.getFont().deriveFont(Font.BOLD, 13f));
        abas.addTab("Alunos", alunoView);
        abas.addTab("Disciplinas", disciplinaView);
        abas.addTab("Tipos de Prova", tipoProvaView);
        abas.addTab("Notas", notaView);
        abas.setSelectedIndex(0); // garante que Alunos abre primeiro

        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(topo, BorderLayout.NORTH);
        getContentPane().add(abas, BorderLayout.CENTER);

        setMinimumSize(new Dimension(700, 480));
        setSize(850, 600);
        setLocationRelativeTo(null);
    }

    public NotaView getNotaView() { return notaView; }
    public AlunoView getAlunoView() { return alunoView; }
    public DisciplinaView getDisciplinaView() { return disciplinaView; }
    public TipoProvaView getTipoProvaView() { return tipoProvaView; }

    public void selecionarAba(int indice) {
        abas.setSelectedIndex(indice);
    }

    public void addTrocaAbaListener(javax.swing.event.ChangeListener l) {
        abas.addChangeListener(l);
    }

    public int getAbaSelecionada() {
        return abas.getSelectedIndex();
    }
}