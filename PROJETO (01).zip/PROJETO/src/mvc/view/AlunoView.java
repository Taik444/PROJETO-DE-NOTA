package mvc.view;

import javax.swing.JComponent;
import javax.swing.JTextField;

public class AlunoView extends CadastroBaseView {

    private final JTextField txtId = campo(10);
    private final JTextField txtNome = campo(30);

    public AlunoView() {
        super("ID", "Nome");
        setFormulario(montarGrade(
                new String[]{"ID (opcional):", "Nome:"},
                new JComponent[]{txtId, txtNome}));
    }

    // ID digitado no formulario (vazio = o banco gera sozinho)
    public String getIdDigitado() { return txtId.getText().trim(); }
    public String getNome() { return txtNome.getText().trim(); }

    @Override protected void preencherFormulario(int l) {
        txtId.setText(String.valueOf(valorTabela(l, 0)));
        txtNome.setText(String.valueOf(valorTabela(l, 1)));
    }

    @Override protected void limparCampos() {
        txtId.setText("");
        txtNome.setText("");
        txtId.requestFocus();
    }
}