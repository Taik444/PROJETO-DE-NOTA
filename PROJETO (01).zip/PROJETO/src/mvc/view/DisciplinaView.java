package mvc.view;

import javax.swing.JComponent;
import javax.swing.JTextField;

public class DisciplinaView extends CadastroBaseView {

    private final JTextField txtNome = campo(30);

    public DisciplinaView() {
        super("ID", "Nome");
        setFormulario(montarGrade(
                new String[]{"Nome:"},
                new JComponent[]{txtNome}));
    }

    public String getNome() { return txtNome.getText().trim(); }

    @Override protected void preencherFormulario(int l) {
        txtNome.setText(String.valueOf(valorTabela(l, 1)));
    }

    @Override protected void limparCampos() {
        txtNome.setText("");
        txtNome.requestFocus();
    }
}