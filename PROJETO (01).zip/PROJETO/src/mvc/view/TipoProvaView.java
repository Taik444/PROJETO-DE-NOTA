package mvc.view;

import javax.swing.JComponent;
import javax.swing.JTextField;

public class TipoProvaView extends CadastroBaseView {

    private final JTextField txtDescricao = campo(30);

    public TipoProvaView() {
        super("ID", "Descricao");
        setFormulario(montarGrade(
                new String[]{"Descricao:"},
                new JComponent[]{txtDescricao}));
    }

    public String getDescricao() { return txtDescricao.getText().trim(); }

    @Override protected void preencherFormulario(int l) {
        txtDescricao.setText(String.valueOf(valorTabela(l, 1)));
    }

    @Override protected void limparCampos() {
        txtDescricao.setText("");
        txtDescricao.requestFocus();
    }
}