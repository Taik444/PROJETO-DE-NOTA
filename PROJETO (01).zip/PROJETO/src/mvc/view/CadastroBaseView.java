package mvc.view;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.MatteBorder;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;

/**
 * Painel base (formulario + botoes + tabela) reaproveitado pelas 4 abas.
 * A View NAO acessa DAO nem Model: quem preenche e le os dados e o Controller.
 * Todos os campos do formulario aceitam digitacao. O ID nao aparece no
 * formulario (o banco gera sozinho); ele continua na 1a coluna da tabela.
 */
public abstract class CadastroBaseView extends JPanel {

    // ---------- Cores (mude aqui para trocar o tema) ----------
    public static final Color AZUL_ESCURO = new Color(0x1F4E79);
    public static final Color AZUL        = new Color(0x2E86DE);
    public static final Color VERDE       = new Color(0x27AE60);
    public static final Color LARANJA     = new Color(0xE67E22);
    public static final Color VERMELHO    = new Color(0xE74C3C);
    public static final Color CINZA       = new Color(0x7F8C8D);
    public static final Color FUNDO       = new Color(0xF4F7FB);
    public static final Color LINHA_ALT   = new Color(0xEAF2FB);
    public static final Color SELECAO     = new Color(0xBBD9F7);

    protected final DefaultTableModel modelo;
    protected final JTable tabela;
    protected final JButton btnNovo = criarBotao("Novo", CINZA);
    protected final JButton btnCadastrar = criarBotao("Cadastrar", VERDE);
    protected final JButton btnAtualizar = criarBotao("Atualizar", LARANJA);
    protected final JButton btnExcluir = criarBotao("Excluir", VERMELHO);
    private final JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));

    protected CadastroBaseView(String... colunas) {
        super(new BorderLayout(10, 10));
        setBackground(FUNDO);
        setBorder(new EmptyBorder(12, 12, 12, 12));

        modelo = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modelo) {
            @Override public Component prepareRenderer(TableCellRenderer renderer, int row, int column) {
                Component comp = super.prepareRenderer(renderer, row, column);
                comp.setForeground(Color.BLACK);
                if (isRowSelected(row)) comp.setBackground(SELECAO);
                else comp.setBackground(row % 2 == 0 ? Color.WHITE : LINHA_ALT);
                return comp;
            }
        };
        tabela.setRowHeight(26);
        tabela.setShowVerticalLines(false);
        tabela.setGridColor(new Color(0xD0DCEA));
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            int row = tabela.getSelectedRow();
            if (!e.getValueIsAdjusting() && row >= 0) preencherFormulario(row);
        });

        JTableHeader cab = tabela.getTableHeader();
        cab.setReorderingAllowed(false);
        cab.setPreferredSize(new Dimension(0, 30));
        cab.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(JTable t, Object v,
                    boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                setBackground(AZUL_ESCURO);
                setForeground(Color.WHITE);
                setFont(getFont().deriveFont(Font.BOLD));
                setHorizontalAlignment(CENTER);
                setBorder(new MatteBorder(0, 0, 0, 1, AZUL));
                return this;
            }
        });

        painelBotoes.setOpaque(false);
        painelBotoes.setBorder(new EmptyBorder(10, 0, 0, 0));
        painelBotoes.add(btnNovo);
        painelBotoes.add(btnCadastrar);
        painelBotoes.add(btnAtualizar);
        painelBotoes.add(btnExcluir);
        btnNovo.addActionListener(e -> limpar());

        JScrollPane rolagem = new JScrollPane(tabela);
        rolagem.setBorder(BorderFactory.createLineBorder(new Color(0xD0DCEA)));
        rolagem.getViewport().setBackground(Color.WHITE);
        add(rolagem, BorderLayout.CENTER);
    }

    // ---------- Construcao visual ----------

    private static JButton criarBotao(String texto, Color cor) {
        JButton b = new JButton(texto);
        b.setUI(new BasicButtonUI()); // faz a cor de fundo funcionar em qualquer tema
        b.setOpaque(true);
        b.setBackground(cor);
        b.setForeground(Color.WHITE);
        b.setFont(b.getFont().deriveFont(Font.BOLD));
        b.setFocusPainted(false);
        b.setBorder(new EmptyBorder(8, 18, 8, 18));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    /** Campo de texto ja estilizado (subclasses usam para criar seus campos). */
    protected static JTextField campo(int colunas) {
        JTextField t = new JTextField(colunas);
        t.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xB8C7DA)),
                new EmptyBorder(4, 6, 4, 6)));
        return t;
    }

    /** Subclasse chama isso no construtor, passando o formulario montado. */
    protected void setFormulario(JPanel form) {
        form.setOpaque(false);
        JPanel cartao = new JPanel(new BorderLayout());
        cartao.setBackground(Color.WHITE);
        cartao.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(0xD0DCEA)),
                new EmptyBorder(12, 14, 12, 14)));
        cartao.add(form, BorderLayout.CENTER);
        cartao.add(painelBotoes, BorderLayout.SOUTH);
        add(cartao, BorderLayout.NORTH);
    }

    protected static JPanel montarGrade(String[] rotulos, JComponent[] campos) {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(4, 4, 4, 8);
        g.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < rotulos.length; i++) {
            JLabel rotulo = new JLabel(rotulos[i]);
            rotulo.setForeground(AZUL_ESCURO);
            rotulo.setFont(rotulo.getFont().deriveFont(Font.BOLD));
            g.gridx = 0; g.gridy = i; g.weightx = 0; g.fill = GridBagConstraints.NONE;
            p.add(rotulo, g);
            g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
            p.add(campos[i], g);
        }
        return p;
    }

    // ---------- Ganchos das subclasses ----------

    /** Copia a linha selecionada da tabela para os campos do formulario. */
    protected abstract void preencherFormulario(int linha);

    /** Limpa os campos do formulario. */
    protected abstract void limparCampos();

    protected Object valorTabela(int linha, int coluna) {
        return modelo.getValueAt(linha, coluna);
    }

    // ---------- API usada pelo Controller ----------

    /** ID da linha selecionada (1a coluna da tabela); vazio se nao houver selecao. */
    public String getId() {
        int r = tabela.getSelectedRow();
        return r < 0 ? "" : String.valueOf(modelo.getValueAt(r, 0));
    }

    public void limpar() {
        tabela.clearSelection();
        limparCampos();
    }

    public void setLinhas(List<Object[]> linhas) {
        modelo.setRowCount(0);
        for (Object[] l : linhas) modelo.addRow(l);
    }

    public boolean temLinhaSelecionada() { return tabela.getSelectedRow() >= 0; }

    public void addCadastrarListener(ActionListener l) { btnCadastrar.addActionListener(l); }
    public void addAtualizarListener(ActionListener l) { btnAtualizar.addActionListener(l); }
    public void addExcluirListener(ActionListener l) { btnExcluir.addActionListener(l); }

    public void mostrarMensagem(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    public void mostrarErro(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public boolean confirmarExclusao() {
        return JOptionPane.showConfirmDialog(this, "Deseja realmente excluir?",
                "Confirmar exclusao", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}