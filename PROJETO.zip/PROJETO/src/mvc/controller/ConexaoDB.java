package mvc.controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Conecta ao banco de dados MariaDB
 */
public class ConexaoDB {

    // ============= CONFIGURAÇÃO DE ACESSO AO BANCO DE DADOS =================
    
    // Conectando na sua própria máquina
    private static final String IPv4_SERVIDOR = "localhost"; 
    
    // Porta padrão do MariaDB / MySQL
    private static final String PORTA = "3306"; 
    
    private static final String BANCO_DE_DADOS = "UNIP"; 

    // Usuário padrão do banco costuma ser 'root'
    private static final String USUARIO = "root"; 
    
    private static final String SENHA = "UNIP"; 
    
    // ========================================================================

    private static final String URL = "jdbc:mariadb://" + IPv4_SERVIDOR + ":" + PORTA + "/" + BANCO_DE_DADOS
            + "?useUnicode=true&characterEncoding=UTF-8&serverTimezone=America/Sao_Paulo"
            + "&useSSL=false&allowPublicKeyRetrieval=true";

    private ConexaoDB() {
        // Construtor privado: classe utilitária, não deve ser instanciada.
    }

    public static Connection getConnection() throws SQLException {
        try {
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (SQLException e) {
            throw new SQLException("Falha ao conectar ao banco de dados '" + BANCO_DE_DADOS + "' em " + IPv4_SERVIDOR + ":" + PORTA + " -> " + e.getMessage(), e);
        }
    }

    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                System.err.println("Aviso: não foi possível fechar a conexão -> " + e.getMessage());
            }
        }
    }
}