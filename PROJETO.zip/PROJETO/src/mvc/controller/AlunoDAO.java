package mvc.controller;


import mvc.model.Aluno;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 
public class AlunoDAO {
 
    public void inserir(Aluno a) throws SQLException {
        String sql = "INSERT INTO alunos (nome_do_aluno) VALUES (?)";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, a.getNome());
            ps.executeUpdate();
        }
    }
 
    public void atualizar(Aluno a) throws SQLException {
        String sql = "UPDATE alunos SET nome_do_aluno = ? WHERE id_aluno = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, a.getNome());
            ps.setInt(2, a.getIdAluno());
            ps.executeUpdate();
        }
    }
 
    public void excluir(int idAluno) throws SQLException {
        String sql = "DELETE FROM alunos WHERE id_aluno = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idAluno);
            ps.executeUpdate();
        }
    }
 
    public List<Aluno> listar() throws SQLException {
        List<Aluno> lista = new ArrayList<>();
        String sql = "SELECT id_aluno, nome_do_aluno FROM alunos ORDER BY nome_do_aluno";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                // matricula não existe no banco, por isso vai null
                Aluno a = new Aluno(rs.getInt("id_aluno"), rs.getString("nome_do_aluno"), null);
                lista.add(a);
            }
        }
        return lista;
    }
}
 