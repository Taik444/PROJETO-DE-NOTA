package mvc.controller;


import mvc.model.Disciplina;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
 
public class DisciplinaDAO {
 
    public void inserir(Disciplina d) throws SQLException {
        String sql = "INSERT INTO disciplinas (disciplina) VALUES (?)";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, d.getNomeDisciplina());
            ps.executeUpdate();
        }
    }
 
    public void atualizar(Disciplina d) throws SQLException {
        String sql = "UPDATE disciplinas SET disciplina = ? WHERE id_disciplina = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, d.getNomeDisciplina());
            ps.setInt(2, d.getIdDisciplina());
            ps.executeUpdate();
        }
    }
 
    public void excluir(int idDisciplina) throws SQLException {
        String sql = "DELETE FROM disciplinas WHERE id_disciplina = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idDisciplina);
            ps.executeUpdate();
        }
    }
 
    public List<Disciplina> listar() throws SQLException {
        List<Disciplina> lista = new ArrayList<>();
        String sql = "SELECT id_disciplina, disciplina FROM disciplinas ORDER BY disciplina";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Disciplina(rs.getInt("id_disciplina"), rs.getString("disciplina")));
            }
        }
        return lista;
    }
}
 