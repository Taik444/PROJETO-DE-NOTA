package mvc.controller;


import mvc.model.TipoProva;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TipoProvaDAO {

    public void inserir(TipoProva t) throws SQLException {
        String sql = "INSERT INTO tipos_de_prova (tipo_de_prova) VALUES (?)";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, t.getDescricao());
            ps.executeUpdate();
        }
    }

    public void atualizar(TipoProva t) throws SQLException {
        String sql = "UPDATE tipos_de_prova SET tipo_de_prova = ? WHERE id_tipo_de_prova = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, t.getDescricao());
            ps.setInt(2, t.getIdTipoProva());
            ps.executeUpdate();
        }
    }

    public void excluir(int idTipoProva) throws SQLException {
        String sql = "DELETE FROM tipos_de_prova WHERE id_tipo_de_prova = ?";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, idTipoProva);
            ps.executeUpdate();
        }
    }

    public List<TipoProva> listar() throws SQLException {
        List<TipoProva> lista = new ArrayList<>();
        String sql = "SELECT id_tipo_de_prova, tipo_de_prova FROM tipos_de_prova ORDER BY tipo_de_prova";
        try (Connection c = ConexaoDB.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new TipoProva(rs.getInt("id_tipo_de_prova"), rs.getString("tipo_de_prova")));
            }
        }
        return lista;
    }
}