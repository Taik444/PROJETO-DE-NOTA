package mvc.view;


import java.util.List;
import javax.swing.*;

/**
 * Aba de Notas. Os combos recebem objetos do Model (Aluno, Disciplina, TipoProva);
 * o que aparece na tela e o toString() de cada um.
 */
public class NotaView extends CadastroBaseView {

    private final JTextField txtId = new JTextField(8);
    private final JComboBox<Object> cbAluno = new JComboBox<>();
    private final JComboBox<Object> cbDisciplina = new JComboBox<>();
    private final JComboBox<Object> cbTipoProva = new JComboBox<>();
    private final JTextField txtValor = new JTextField(8);

    public NotaView() {
        super("ID", "Aluno", "Disciplina", "Tipo de Prova", "Nota");
        txtId.setEditable(false);
        setFormulario(montarGrade(
                new String[]{"ID:", "Aluno:", "Disciplina:", "Tipo de Prova:", "Nota:"},
                new JComponent[]{txtId, cbAluno, cbDisciplina, cbTipoProva, txtValor}));
    }

    // ---------- Combos (Controller carrega) ----------
    public void setAlunos(List<?> l) { carregar(cbAluno, l); }
    public void setDisciplinas(List<?> l) { carregar(cbDisciplina, l); }
    public void setTiposProva(List<?> l) { carregar(cbTipoProva, l); }

    private void carregar(JComboBox<Object> cb, List<?> itens) {
        cb.removeAllItems();
        for (Object o : itens) cb.addItem(o);
    }

    // ---------- Leitura dos campos ----------
    public String getId() { return txtId.getText().trim(); }
    public Object getAlunoSelecionado() { return cbAluno.getSelectedItem(); }
    public Object getDisciplinaSelecionada() { return cbDisciplina.getSelectedItem(); }
    public Object getTipoProvaSelecionado() { return cbTipoProva.getSelectedItem(); }
    public String getValor() { return txtValor.getText().trim().replace(',', '.'); }

    @Override protected void preencherFormulario(int l) {
        txtId.setText(String.valueOf(valorTabela(l, 0)));
        selecionarPorTexto(cbAluno, String.valueOf(valorTabela(l, 1)));
        selecionarPorTexto(cbDisciplina, String.valueOf(valorTabela(l, 2)));
        selecionarPorTexto(cbTipoProva, String.valueOf(valorTabela(l, 3)));
        txtValor.setText(String.valueOf(valorTabela(l, 4)));
    }

    private void selecionarPorTexto(JComboBox<Object> cb, String texto) {
        for (int i = 0; i < cb.getItemCount(); i++) {
            if (String.valueOf(cb.getItemAt(i)).equals(texto)) {
                cb.setSelectedIndex(i);
                return;
            }
        }
    }

    @Override protected void limparCampos() {
        txtId.setText("");
        txtValor.setText("");
        if (cbAluno.getItemCount() > 0) cbAluno.setSelectedIndex(0);
        if (cbDisciplina.getItemCount() > 0) cbDisciplina.setSelectedIndex(0);
        if (cbTipoProva.getItemCount() > 0) cbTipoProva.setSelectedIndex(0);
    }
}