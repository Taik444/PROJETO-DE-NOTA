package mvc.view;


import javax.swing.*;

public class AlunoView extends CadastroBaseView {

    private final JTextField txtId = new JTextField(8);
    private final JTextField txtRa = new JTextField(20);
    private final JTextField txtNome = new JTextField(30);

    public AlunoView() {
        super("ID", "RA", "Nome");
        txtId.setEditable(false);
        setFormulario(montarGrade(
                new String[]{"ID:", "RA:", "Nome:"},
                new JComponent[]{txtId, txtRa, txtNome}));
    }

    public String getId() { return txtId.getText().trim(); }
    public String getRa() { return txtRa.getText().trim(); }
    public String getNome() { return txtNome.getText().trim(); }

    @Override protected void preencherFormulario(int l) {
        txtId.setText(String.valueOf(valorTabela(l, 0)));
        txtRa.setText(String.valueOf(valorTabela(l, 1)));
        txtNome.setText(String.valueOf(valorTabela(l, 2)));
    }

    @Override protected void limparCampos() {
        txtId.setText(""); txtRa.setText(""); txtNome.setText("");
        txtRa.requestFocus();
    }
}