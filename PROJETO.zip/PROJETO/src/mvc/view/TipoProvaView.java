package mvc.view;


import javax.swing.*;

public class TipoProvaView extends CadastroBaseView {

    private final JTextField txtId = new JTextField(8);
    private final JTextField txtDescricao = new JTextField(30);

    public TipoProvaView() {
        super("ID", "Descricao");
        txtId.setEditable(false);
        setFormulario(montarGrade(
                new String[]{"ID:", "Descricao:"},
                new JComponent[]{txtId, txtDescricao}));
    }

    public String getId() { return txtId.getText().trim(); }
    public String getDescricao() { return txtDescricao.getText().trim(); }

    @Override protected void preencherFormulario(int l) {
        txtId.setText(String.valueOf(valorTabela(l, 0)));
        txtDescricao.setText(String.valueOf(valorTabela(l, 1)));
    }

    @Override protected void limparCampos() {
        txtId.setText(""); txtDescricao.setText("");
        txtDescricao.requestFocus();
    }
}