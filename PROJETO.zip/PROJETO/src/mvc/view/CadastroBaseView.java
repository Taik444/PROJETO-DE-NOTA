package mvc.view;


import java.awt.*;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

/**
 * Painel base (tabela + formulario + botoes) reaproveitado pelas 4 abas.
 * A View NAO acessa DAO nem Model: quem preenche e le os dados e o Controller.
 */
public abstract class CadastroBaseView extends JPanel {

    protected final DefaultTableModel modelo;
    protected final JTable tabela;
    protected final JButton btnNovo = new JButton("Novo");
    protected final JButton btnCadastrar = new JButton("Cadastrar");
    protected final JButton btnAtualizar = new JButton("Atualizar");
    protected final JButton btnExcluir = new JButton("Excluir");
    private final JPanel painelBotoes = new JPanel(new FlowLayout(FlowLayout.LEFT));

    protected CadastroBaseView(String... colunas) {
        super(new BorderLayout(8, 8));
        setBorder(new EmptyBorder(10, 10, 10, 10));

        modelo = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        tabela = new JTable(modelo);
        tabela.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabela.getSelectionModel().addListSelectionListener(e -> {
            int row = tabela.getSelectedRow();
            if (!e.getValueIsAdjusting() && row >= 0) preencherFormulario(row);
        });

        painelBotoes.add(btnNovo);
        painelBotoes.add(btnCadastrar);
        painelBotoes.add(btnAtualizar);
        painelBotoes.add(btnExcluir);
        btnNovo.addActionListener(e -> limpar());

        add(new JScrollPane(tabela), BorderLayout.CENTER);
    }

    /** Subclasse chama isso no construtor, passando o formulario montado. */
    protected void setFormulario(JPanel form) {
        JPanel norte = new JPanel(new BorderLayout());
        norte.add(form, BorderLayout.NORTH);
        norte.add(painelBotoes, BorderLayout.SOUTH);
        add(norte, BorderLayout.NORTH);
    }

    protected static JPanel montarGrade(String[] rotulos, JComponent[] campos) {
        JPanel p = new JPanel(new GridBagLayout());
        GridBagConstraints g = new GridBagConstraints();
        g.insets = new Insets(3, 3, 3, 3);
        g.anchor = GridBagConstraints.WEST;
        for (int i = 0; i < rotulos.length; i++) {
            g.gridx = 0; g.gridy = i; g.weightx = 0; g.fill = GridBagConstraints.NONE;
            p.add(new JLabel(rotulos[i]), g);
            g.gridx = 1; g.weightx = 1; g.fill = GridBagConstraints.HORIZONTAL;
            p.add(campos[i], g);
        }
        return p;
    }

    /** Copia a linha selecionada da tabela para os campos do formulario. */
    protected abstract void preencherFormulario(int linha);

    /** Limpa os campos do formulario. */
    protected abstract void limparCampos();

    protected Object valorTabela(int linha, int coluna) {
        return modelo.getValueAt(linha, coluna);
    }

    // ---------- API usada pelo Controller ----------

    public void limpar() {
        tabela.clearSelection();
        limparCampos();
    }

    public void setLinhas(List<Object[]> linhas) {
        modelo.setRowCount(0);
        for (Object[] l : linhas) modelo.addRow(l);
    }

    public boolean temLinhaSelecionada() { return tabela.getSelectedRow() >= 0; }

    public void addCadastrarListener(ActionListener l) { btnCadastrar.addActionListener(l); }
    public void addAtualizarListener(ActionListener l) { btnAtualizar.addActionListener(l); }
    public void addExcluirListener(ActionListener l) { btnExcluir.addActionListener(l); }

    public void mostrarMensagem(String msg) {
        JOptionPane.showMessageDialog(this, msg);
    }

    public void mostrarErro(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Erro", JOptionPane.ERROR_MESSAGE);
    }

    public boolean confirmarExclusao() {
        return JOptionPane.showConfirmDialog(this, "Deseja realmente excluir?",
                "Confirmar exclusao", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}