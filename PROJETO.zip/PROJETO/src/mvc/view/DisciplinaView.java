package mvc.view;


import javax.swing.*;

public class DisciplinaView extends CadastroBaseView {

    private final JTextField txtId = new JTextField(8);
    private final JTextField txtNome = new JTextField(30);

    public DisciplinaView() {
        super("ID", "Nome");
        txtId.setEditable(false);
        setFormulario(montarGrade(
                new String[]{"ID:", "Nome:"},
                new JComponent[]{txtId, txtNome}));
    }

    public String getId() { return txtId.getText().trim(); }
    public String getNome() { return txtNome.getText().trim(); }

    @Override protected void preencherFormulario(int l) {
        txtId.setText(String.valueOf(valorTabela(l, 0)));
        txtNome.setText(String.valueOf(valorTabela(l, 1)));
    }

    @Override protected void limparCampos() {
        txtId.setText(""); txtNome.setText("");
        txtNome.requestFocus();
    }
}
