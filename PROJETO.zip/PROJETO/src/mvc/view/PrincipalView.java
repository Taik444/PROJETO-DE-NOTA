package mvc.view;


import java.awt.Dimension;
import javax.swing.*;

public class PrincipalView extends JFrame {

    private final NotaView notaView = new NotaView();
    private final AlunoView alunoView = new AlunoView();
    private final DisciplinaView disciplinaView = new DisciplinaView();
    private final TipoProvaView tipoProvaView = new TipoProvaView();

    public PrincipalView() {
        super("Controle de Notas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JTabbedPane abas = new JTabbedPane();
        abas.addTab("Notas", notaView);
        abas.addTab("Alunos", alunoView);
        abas.addTab("Disciplinas", disciplinaView);
        abas.addTab("Tipos de Prova", tipoProvaView);

        add(abas);
        setMinimumSize(new Dimension(700, 480));
        setSize(800, 550);
        setLocationRelativeTo(null);
    }

    public NotaView getNotaView() { return notaView; }
    public AlunoView getAlunoView() { return alunoView; }
    public DisciplinaView getDisciplinaView() { return disciplinaView; }
    public TipoProvaView getTipoProvaView() { return tipoProvaView; }

    /** Util para o Controller: abas que dependem de outras precisam recarregar os combos. */
    public void selecionarAba(int indice) {
        ((JTabbedPane) getContentPane().getComponent(0)).setSelectedIndex(indice);
    }
}