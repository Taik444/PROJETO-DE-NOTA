package mvc.model;

public class Nota {
    private int idNota;
    private Aluno aluno;
    private Disciplina disciplina;
    private TipoProva tipoProva;
    private double valorNota;
 
    // Construtor
    public Nota(int idNota, Aluno aluno, Disciplina disciplina, TipoProva tipoProva, double valorNota) {
        this.idNota = idNota;
        this.aluno = aluno;
        this.disciplina = disciplina;
        this.tipoProva = tipoProva;
        setValorNota(valorNota); // Utiliza o setter para aplicar a validação desde a criação
    }
 
    // Getters e Setters
    public int getIdNota() {
        return idNota;
    }
 
    public void setIdNota(int idNota) {
        this.idNota = idNota;
    }
 
    public Aluno getAluno() {
        return aluno;
    }
 
    public void setAluno(Aluno aluno) {
        this.aluno = aluno;
    }
 
    public Disciplina getDisciplina() {
        return disciplina;
    }
 
    public void setDisciplina(Disciplina disciplina) {
        this.disciplina = disciplina;
    }
 
    public TipoProva getTipoProva() {
        return tipoProva;
    }
 
    public void setTipoProva(TipoProva tipoProva) {
        this.tipoProva = tipoProva;
    }
 
    public double getValorNota() {
        return valorNota;
    }
 
    public void setValorNota(double valorNota) {
        if (valorNota >= 0.0 && valorNota <= 10.0) {
            this.valorNota = valorNota;
        } else {
            throw new IllegalArgumentException("Nota inválida! O valor deve estar entre 0.0 e 10.0.");
        }
    }
}