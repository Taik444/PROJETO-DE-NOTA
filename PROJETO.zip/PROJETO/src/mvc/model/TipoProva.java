package mvc.model;


public class TipoProva {
    private int idTipoProva;
    private String descricao;
 
    // Construtor
    public TipoProva(int idTipoProva, String descricao) {
        this.idTipoProva = idTipoProva;
        this.descricao = descricao;
    }
 
    // Getters e Setters
    public int getIdTipoProva() {
        return idTipoProva;
    }
 
    public void setIdTipoProva(int idTipoProva) {
        this.idTipoProva = idTipoProva;
    }
 
    public String getDescricao() {
        return descricao;
    }
 
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
}