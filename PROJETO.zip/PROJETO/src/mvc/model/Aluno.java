package mvc.model;
 
public class Aluno {
    private int idAluno;
    private String nome;
    private String matricula;
 
    // Construtor
    public Aluno(int idAluno, String nome, String matricula) {
        this.idAluno = idAluno;
        this.nome = nome;
        this.matricula = matricula;
    }
 
    // Getters e Setters
    public int getIdAluno() {
        return idAluno;
    }
 
    public void setIdAluno(int idAluno) {
        this.idAluno = idAluno;
    }
 
    public String getNome() {
        return nome;
    }
 
    public void setNome(String nome) {
        this.nome = nome;
    }
 
    public String getMatricula() {
        return matricula;
    }
 
    public void setMatricula(String matricula) {
        this.matricula = matricula;
    }
}
 