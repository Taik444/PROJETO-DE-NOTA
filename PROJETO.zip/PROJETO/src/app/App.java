package app;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import mvc.view.PrincipalView;

public class App {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                PrincipalView view = new PrincipalView();
                view.setVisible(true);
            }
        });
    }
}